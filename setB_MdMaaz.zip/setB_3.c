#include <stdio.h>

void revBits(int);
int main()
{
    int a[10], num, i, j;
    printf("\n Enter the Number: ");
    scanf("%d", &num);
    revBits(num);

}

void revBits(int num)
{
     int a[10],i, j;
    for(i = 0; num > 0; i++)
    {
        a[i] = num % 2;
        num = num / 2;
    }
   
    printf("\n Before = ");
    for(j=i-1;j >= 0; j--)
    {
        printf("%d", a[j]);
    }
    printf("\n After = ");
    for(i=0;i <= 3; i++) 
    {
        printf("%d", a[i]);
    }
}


