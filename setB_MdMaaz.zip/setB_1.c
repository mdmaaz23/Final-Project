#include <stdio.h>
#include <string.h>
#include <math.h>

int main()
{
    int i,j,n;
    printf("Enter the Size of string:\n");
    scanf("%d",&n);
    char str[n];
    for(i=0;i<n;i++)
    {
    scanf("%s",&str[i]);
    }
    for(i=0;i<n;)
    {
        if((str[i] == str[i+1] ) && (i >= 0) && str[i]!='\0')
        {
            j=i;
            while(str[j]!='\0')
            {
            str[j]=str[j+2];
        str[j+1]=str[j+3];
        j+=2;
            }
            i--;
        }
        else
        {
            i++;
        }
    }
    if(str[0]=='\0')
       printf("Empty String");
    else
       printf("Reduced String: %s\n",str);

    return 0;
}